import streamlit as st
from utils import load_csv_data
import matplotlib.pyplot as plt

st.set_page_config(layout="wide")
st.title("📊 StockSense: Smart Forecasting Dashboard")

# Load data from file
file_path = "data/tata_stock.csv"
df = load_csv_data(file_path)

# Show success
st.success("✅ Tata Motors stock data loaded!")

# Show last 10 rows
st.subheader("📁 Latest Stock Data")
st.dataframe(df.tail(10))

# Plot Closing price
if 'Close' in df.columns:
    st.subheader("📈 Closing Price Trend")
    st.line_chart(df['Close'])
else:
    st.warning("No 'Close' column found to plot trend.")

