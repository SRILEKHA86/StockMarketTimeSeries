import pandas as pd

def load_csv_data(file_path):
    df = pd.read_csv(file_path)

    # Handle different column names
    if 'Date' in df.columns:
        df['Date'] = pd.to_datetime(df['Date'])
        df.set_index('Date', inplace=True)
    elif 'date' in df.columns:
        df['date'] = pd.to_datetime(df['date'])
        df.set_index('date', inplace=True)
    
    df = df.sort_index()
    return df
